<?php
$host = "sql101.infinityfree.com";
$user = "if0_43362683";
$pass = "Subaccount2601";
$db   = "if0_43362683_finals";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database connection failed.");
}
?>